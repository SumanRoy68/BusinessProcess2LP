package xmlparser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;


public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String inputFileName = "D:\\JavaPrograms\\Ishita\\testBPMProcesses\\invoiceReceipt.bpmn";
		String outputFileName = null;
		
		boolean flag=true;
		
		if (inputFileName.endsWith(".xml")) {
			outputFileName = inputFileName.substring(0, inputFileName.length() - 4) + ".pl";
		} else if (inputFileName.endsWith(".bpmn")) {
			outputFileName = inputFileName.substring(0, inputFileName.length() - 5) + ".pl";
		} else {
			System.out.println("File extension unknown. Please select a .xml or .bpmn file.");
			flag=false;
		}
		
		if(flag){
			
			File outputFile = new File(outputFileName);
			FileWriter fstream=null;
			try {
				fstream = new FileWriter(outputFile.getAbsoluteFile());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			BufferedWriter out = new BufferedWriter(fstream);
			
			File inputFile = new File(inputFileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder=null;
	        
			try {
				dBuilder = dbFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	        Document doc = null;
	        
			try {
				doc = dBuilder.parse(inputFile);
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	        doc.getDocumentElement().normalize();
	        
	        Parser.mainParser(doc, out);
	        
	        try {
	        	
				out.flush();
				out.close();
			} catch (IOException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        System.out.println("Parsing complete. Prolog code available at : "+outputFile);
	        
		}
		
	}

}
