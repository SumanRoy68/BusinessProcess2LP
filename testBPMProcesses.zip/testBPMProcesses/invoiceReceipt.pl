happens3(start(A),T,H) :- member(happens(start(A),T),H).
happens3(end(A),T2,H) :- happens3(start(A),T1,H), dur_id(A,Y), T2 is T1+Y.

dur_id( act(A,_), T ) :- dur( A, T ).

newId( Action, Id_pre, Id ) :- action_number(Action,C),no_of_actions(N),Id is Id_pre*N + C.

follows(A1,A2) :- no_of_actions(N),limited_history([H0|H1],N),H0=happens(start(act(A1,_)),_),H1=[happens(start(act(A2,_)),_)|_],happens3(end(act(A1,_)),_,[H0|H1]).
follows(A1,A2) :- no_of_actions(N),limited_history([H0|H1],N),H1=[happens(start(act(A1,_)),_)|[happens(start(act(A2,_)),_)|_]],happens3(end(act(A1,_)),_,[H0|H1]).

list_follows(N,A,[A1|L]) :- N>1, N1 is N-1, follows(A1,A), list_follows(N1,A1,L).
list_follows(N,A,[A1]) :- N>0, follows(A1,A).

no_of_actions(6).

action_number(assignApprover,0).
action_number(approveInvoice,1).
action_number(reviewInvoice,2).
action_number(prepareBankTransfer,3).
action_number(archiveInvoice,4).


agent(teamAssistant).
agent(approver).
agent(accountant).

qualified(accountant,prepareBankTransfer).
qualified(accountant,archiveInvoice).
qualified(teamAssistant,reviewInvoice).
qualified(approver,approveInvoice).
qualified(teamAssistant,assignApprover).

dur(assignApprover,4).
dur(approveInvoice,7).
dur(reviewInvoice,3).
dur(prepareBankTransfer,8).
dur(archiveInvoice,2).
sequential(assignApprover,approveInvoice).

sequential(prepareBankTransfer,archiveInvoice).

pair(prepareBankTransfer,yes1).

pair(reviewInvoice,no1).
pair(approveInvoice,yes2).

pair(null,no2).

holds_at(yes1,T,_):-T > 0.
holds_at(no2,T,_):-T>0. 
holds_at(yes2,0,_).
holds_at(no1,0,_).

xor_split(reviewInvoice,[null,approveInvoice]).
xor_split(approveInvoice,[reviewInvoice,prepareBankTransfer]).


step(happens(start(A),T),H) :- happens3(end(A0),T,H),sequential_with_ids(A0,A),not( happens3(start(A),T,H) ).

step(happens(start(act(Ai,J)),T),H) :-xor_split(Aname,L), happens3(end(act(Aname,I)),T,H), member(Ai,L), pair(Ai,Cond),holds_at(Cond,T,H), not( happens3(start(act(Ai,J)),T,H)), newId(Ai,I,J).

sequential_with_ids(act(A1,I1),act(A2,I2)) :- sequential( A1, A2 ),newId( A2, I1, I2 ).


extend_history( H, [Happens|H] ) :- step( Happens, H ).

limited_history( HH, N ) :- 1<N, N1 is N-1,limited_history( H, N1 ),extend_history( H, HH ).
limited_history( [happens(start(act(assignApprover,1)),0)], N ) :- 0<N.

