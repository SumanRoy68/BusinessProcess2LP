happens3(start(A),T,H) :- member(happens(start(A),T),H).
happens3(end(A),T2,H) :- happens3(start(A),T1,H), dur_id(A,Y), T2 is T1+Y.

dur_id( act(A,_), T ) :- dur( A, T ).

newId( Action, Id_pre, Id ) :- action_number(Action,C),no_of_actions(N),Id is Id_pre*N + C.

follows(A1,A2) :- no_of_actions(N),limited_history([H0|H1],N),H0=happens(start(act(A1,_)),_),H1=[happens(start(act(A2,_)),_)|_],happens3(end(act(A1,_)),_,[H0|H1]).
follows(A1,A2) :- no_of_actions(N),limited_history([H0|H1],N),H1=[happens(start(act(A1,_)),_)|[happens(start(act(A2,_)),_)|_]],happens3(end(act(A1,_)),_,[H0|H1]).

list_follows(N,A,[A1|L]) :- N>1, N1 is N-1, follows(A1,A), list_follows(N1,A1,L).
list_follows(N,A,[A1]) :- N>0, follows(A1,A).

no_of_actions(10).

action_number(requestLoan,0).
action_number(consolidateAndDigitalizeData,1).
action_number(analyzeFinancialData,2).
action_number(prepareAndTransmitRefusalLetter,3).
action_number(verifyCreditRecordWithCreditOffices,4).
action_number(prepareDetailedAnalysisOfFinancialData,5).
action_number(reviewDetailedAnalysis,6).
action_number(prepareAndTransmitAcceptalLetter,7).
action_number(prepareAndTransmitRefusalLetter,8).

dur(requestLoan,2).
dur(consolidateAndDigitalizeData,2).
dur(analyzeFinancialData,2).
dur(prepareAndTransmitRefusalLetter,2).
dur(verifyCreditRecordWithCreditOffices,2).
dur(prepareDetailedAnalysisOfFinancialData,2).
dur(reviewDetailedAnalysis,2).
dur(prepareAndTransmitAcceptalLetter,2).
dur(prepareAndTransmitRefusalLetter,2).

agent(customer).
agent(sales).
agent(administration).

qualified(administration,verifyCreditRecordWithCreditOffices).
qualified(sales,reviewDetailedAnalysis).
qualified(sales,analyzeFinancialData).
qualified(sales,consolidateAndDigitalizeData).
qualified(sales,prepareAndTransmitRefusalLetter).
qualified(customer,requestLoan).
qualified(administration,prepareDetailedAnalysisOfFinancialData).
qualified(sales,prepareAndTransmitAcceptalLetter).

sequential(requestLoan,consolidateAndDigitalizeData).

sequential(consolidateAndDigitalizeData,analyzeFinancialData).

sequential(verifyCreditRecordWithCreditOffices,prepareDetailedAnalysisOfFinancialData).

sequential(prepareDetailedAnalysisOfFinancialData,reviewDetailedAnalysis).

pair(prepareAndTransmitRefusalLetter,no1).
pair(prepareAndTransmitAcceptalLetter,yes2).
pair(prepareAndTransmitRefusalLetter,no2).

pair(verifyCreditRecordWithCreditOffices,yes1).



xor_split(reviewDetailedAnalysis,[prepareAndTransmitAcceptalLetter,prepareAndTransmitRefusalLetter]).
xor_split(analyzeFinancialData,[prepareAndTransmitRefusalLetter,verifyCreditRecordWithCreditOffices]).


step(happens(start(A),T),H) :- happens3(end(A0),T,H),sequential_with_ids(A0,A),not( happens3(start(A),T,H) ).

step(happens(start(act(Ai,J)),T),H) :-xor_split(Aname,L), happens3(end(act(Aname,I)),T,H), member(Ai,L), pair(Ai,Cond),holds_at(Cond,T,H), not( happens3(start(act(Ai,J)),T,H)), newId(Ai,I,J).

sequential_with_ids(act(A1,I1),act(A2,I2)) :- sequential( A1, A2 ),newId( A2, I1, I2 ).


extend_history( H, [Happens|H] ) :- step( Happens, H ).

limited_history( HH, N ) :- 1<N, N1 is N-1,limited_history( H, N1 ),extend_history( H, HH ).
limited_history( [happens(start(act(requestLoan,1)),0)], N ) :- 0<N.

